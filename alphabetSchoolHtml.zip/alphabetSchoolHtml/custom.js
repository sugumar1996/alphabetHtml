 $(document).ready(function() {
    $('.menubar').click(function() {
        $('.ds-social.active').removeClass('.active');
    });
});

